# -*- coding: utf-8 -*-
"""到期提醒官 · 简称匹配回归测试（卡面验收：≥5 例）

覆盖两类：
  ① 卡面点名的 5 个简称：工行 / 中行 / 建行 / 农行 / 招行
  ② 已截止的公司能正确返回「已截止 N 天」
  ③ 兜底：表里没有的企业、歧义简称
"""
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
RESOLVE = os.path.join(HERE, "resolve.py")
PY = sys.executable

# (输入, 期望出现在输出里的子串)
CASES = [
    ("工行", "中国工商银行"),
    ("中行", "中国银行"),
    ("建行", "中国建设银行"),
    ("农行", "中国农业银行"),
    ("招行", "招商银行"),
    ("交行", "交通银行"),
    ("邮储", "邮储银行"),
    ("国网", "国家电网"),
    ("移动", "中国移动"),
]

# 已截止断言：(输入, 期望子串)
EXPIRED_CASES = [
    ("工行", "已截止 2 天"),
    ("中行", "已截止 1 天"),
    ("邮储", "已截止 3 天"),
]

# 负例
MISS_CASES = ["某某不存在集团"]
AMBIG_CASES = ["中信"]


def run(q):
    p = subprocess.run([PY, RESOLVE, q], capture_output=True, text=True, encoding="utf-8", cwd=PKG)
    return (p.stdout or "") + (p.stderr or "")


def main():
    ok = fail = 0
    print("=" * 60)
    print("简称匹配测试")
    print("=" * 60)
    for q, expect in CASES:
        out = run(q)
        good = expect in out
        print("  [%s] %s → %s" % ("✅" if good else "❌", q, expect))
        ok, fail = (ok + 1, fail) if good else (ok, fail + 1)

    print()
    print("=" * 60)
    print("已截止断言（必须诚实显示，不许隐藏）")
    print("=" * 60)
    for q, expect in EXPIRED_CASES:
        out = run(q)
        good = expect in out
        print("  [%s] %s → %s" % ("✅" if good else "❌", q, expect))
        ok, fail = (ok + 1, fail) if good else (ok, fail + 1)

    print()
    print("=" * 60)
    print("负例 / 歧义")
    print("=" * 60)
    for q in MISS_CASES:
        out = run(q)
        good = "表里没有这家企业" in out
        print("  [%s] %s → 明确回答「表里没有」" % ("✅" if good else "❌", q))
        ok, fail = (ok + 1, fail) if good else (ok, fail + 1)
    for q in AMBIG_CASES:
        out = run(q)
        good = "请确认你问的是哪一家" in out
        print("  [%s] %s → 列出多家并请使用者确认（不替他挑）" % ("✅" if good else "❌", q))
        ok, fail = (ok + 1, fail) if good else (ok, fail + 1)

    print()
    print("-" * 60)
    print("合计：通过 %d / 失败 %d  →  %s" % (ok, fail, "✅ 全部通过" if fail == 0 else "❌ 有失败"))
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
