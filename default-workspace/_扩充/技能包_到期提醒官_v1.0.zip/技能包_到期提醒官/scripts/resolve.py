# -*- coding: utf-8 -*-
"""到期提醒官 · 查询解析脚本 v1.0（落地卡 25 · 任务 B）

输入公司名（全称或简称）→ 返回 剩余天数 / 截止日 / 是否已截止 / 核实状态。

铁律：
  1. 不做预测（不猜"你还能不能赶上"）
  2. 不给建议（不推荐投哪家）
  3. 已截止的必须诚实显示，不许隐藏
  4. 边界声明不可省

数据表：复用「求职时间表 AI 助手」技能包的 timetable.json，本包不另建一份。
"""
import argparse
import datetime
import json
import os
import re
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
WS = os.path.dirname(PKG)
DEFAULT_ALIAS = os.path.join(PKG, "data", "alias_map.json")

# 数据表候选位置（按序查找，找到即停）
DATA_CANDIDATES = [
    os.path.join(PKG, "..", "技能包_时间表查询官", "data", "timetable.json"),
    os.path.join(PKG, "..", "..", "技能包_时间表查询官", "data", "timetable.json"),
    os.path.join(WS, "技能包_时间表查询官", "data", "timetable.json"),
    os.path.join(os.getcwd(), "技能包_时间表查询官", "data", "timetable.json"),
    os.path.join(PKG, "data", "timetable.json"),
]

BOUNDARY = "数据以最后核验日期为准，投递前请以官网为准。"

NOISE = ["股份有限公司", "有限公司", "有限责任公司", "集团", "（", "）", "(", ")", " ", "·", " ", "-"]


def find_data(explicit=None):
    if explicit:
        if not os.path.isfile(explicit):
            raise SystemExit("❌ 找不到数据表：%s" % explicit)
        return explicit
    env = os.environ.get("TIMETABLE_JSON")
    if env and os.path.isfile(env):
        return env
    for p in DATA_CANDIDATES:
        if os.path.isfile(p):
            return os.path.normpath(p)
    raise SystemExit(
        "❌ 找不到 timetable.json。已查找：\n  - " + "\n  - ".join(os.path.normpath(p) for p in DATA_CANDIDATES)
        + "\n  请用 --data 指定路径，或设置环境变量 TIMETABLE_JSON。"
    )


def norm(s):
    s = (s or "").strip()
    for n in NOISE:
        s = s.replace(n, "")
    return s.lower()


def load_alias(path):
    if not os.path.isfile(path):
        return {}
    with open(path, encoding="utf-8") as f:
        return json.load(f).get("alias", {})


def match(query, companies, alias):
    """返回 (匹配到的企业列表, 匹配方式)"""
    q = (query or "").strip()
    if not q:
        return [], "空查询"
    nq = norm(q)

    # ① 全称精确
    hits = [c for c in companies if c["company"] == q]
    if hits:
        return hits, "全称精确"

    # ② 简称表
    if q in alias:
        names = alias[q]
        hits = [c for c in companies if c["company"] in names]
        if hits:
            return hits, "简称表"

    # ③ 归一化后相等
    hits = [c for c in companies if norm(c["company"]) == nq]
    if hits:
        return hits, "归一化精确"

    # ④ 子串包含（双向）
    hits = [c for c in companies if nq and (nq in norm(c["company"]) or norm(c["company"]) in nq)]
    if hits:
        return hits, "子串包含"

    return [], "未匹配"


def is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def render(hits, meta, data_date):
    L = []
    A = L.append
    if len(hits) == 1:
        c = hits[0]
        dl = c.get("days_left")
        if is_int(dl):
            if dl < 0:
                A("**%s：已截止 %d 天**（截止日 %s，核验日期 %s）" % (c["company"], -dl, c.get("deadline", ""), c.get("verified_at", "")))
            elif dl == 0:
                A("**%s：截止日就在今天**（截止日 %s，核验日期 %s）" % (c["company"], c.get("deadline", ""), c.get("verified_at", "")))
            else:
                A("**%s：还剩 %d 天**（截止日 %s，核验日期 %s）" % (c["company"], dl, c.get("deadline", ""), c.get("verified_at", "")))
        else:
            A("**%s：无固定截止日**（口径「%s」，核验日期 %s）" % (c["company"], (c.get("deadline") or "未列明"), c.get("verified_at", "")))
    else:
        A("「%s」在表里对应 %d 家，请确认你问的是哪一家：" % (hits[0]["company"] if hits else "", len(hits)))

    A("")
    A("| 企业 | 截止日 | 剩余天数 | 是否已截止 | 核实状态 | 核验日期 |")
    A("|---|---|---|---|---|---|")
    for c in hits:
        dl = c.get("days_left")
        if is_int(dl):
            left = str(dl)
            expired = "是（已截止 %d 天）" % (-dl) if dl < 0 else "否"
        else:
            left = "无固定截止"
            expired = "不适用"
        A("| %s | %s | %s | %s | %s | %s |" % (
            c["company"], c.get("deadline", ""), left, expired,
            c.get("verify_status", ""), c.get("verified_at", "")))
    A("")
    A("> " + BOUNDARY)
    A("> 数据核验日期：%s　｜　数据表版本：%s" % (data_date, meta.get("version", "")))
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("query", nargs="*", help="公司名（全称或简称）")
    ap.add_argument("--data", default=None)
    ap.add_argument("--alias", default=DEFAULT_ALIAS)
    args = ap.parse_args()

    data_path = find_data(args.data)
    with open(data_path, encoding="utf-8") as f:
        data = json.load(f)
    companies = data["companies"]
    meta = data.get("meta", {})
    data_date = meta.get("data_date") or datetime.date.today().isoformat()
    alias = load_alias(args.alias)

    q = " ".join(args.query).strip()
    hits, how = match(q, companies, alias)
    if not hits:
        print("表里没有这家企业：%s" % q)
        print()
        print("> " + BOUNDARY)
        return
    print("匹配方式：%s" % how)
    print(render(hits, meta, data_date))


if __name__ == "__main__":
    main()
